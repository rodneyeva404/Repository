package edu.clayton.csit.antlab.pkg1;



/** 
 * CSCI 4320 Ant Lab
 *
 * AntLab12.java helper class
 */
 public class AntLab12 {
    
    
   /**
    * retrieves a pre-stored string message 
    * @return the string
    */
    public String getMessage() {
        return " You";
    }
    
 } 